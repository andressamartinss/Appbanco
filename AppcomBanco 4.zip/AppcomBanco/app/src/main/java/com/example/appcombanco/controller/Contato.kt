package com.example.appcombanco.controller

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName =  "contato")//falando para o banco construir contatos
data class Contato(
    @PrimaryKey(autoGenerate = true)//tipo um contador vai adicionando 1
    val id: Int? = 0,// a ? significa que esta sendo inicializado
    val nome: String,
    val sobrenome: String,
    val telefone: String,
)
