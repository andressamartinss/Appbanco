package com.example.appcombanco.model
//uma vai conversar com a outra classe contato
//aqui sera tuda modelagem
data class Contato(

    val nome: String = "",
    val sobrenome: String = "",
    val telefone: String = "",

    )