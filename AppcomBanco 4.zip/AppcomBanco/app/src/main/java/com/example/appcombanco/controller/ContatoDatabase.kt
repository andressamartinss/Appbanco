package com.example.appcombanco.controller

import androidx.room.Database
//classe de abstração
@Database(
    //chamando a classe Contato e falando da versão que ela esta
    //entities é a entidade temos uma só que é classe contato
    entities = [Contato::class],
    version = 1
)
abstract class ContatoDatabase {
}