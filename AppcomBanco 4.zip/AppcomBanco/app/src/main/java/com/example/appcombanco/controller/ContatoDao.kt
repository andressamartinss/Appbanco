package com.example.appcombanco.controller

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.appcombanco.model.Contato

//classe de interface
// interligação com back
// DAO acesso ao banco
@Dao
interface ContatoDao {
    @Insert
    fun insertContato(contato: Contato)//puxando a classe contato para entrar tudo esta la dento aqui, que vai realizar o fun

    @Update
    fun updateContato(contato: Contato)
    @Delete
    fun deleteContato(contato: Contato)
    //chamando a classe contao como se ela fosse um banco de dados
    // chamando nome sobrenome  e telefone da classe contato da packge controller
    @Query("SELECT * FROM contato ORDER BY nome ASC")
    fun getContatoOrderPeloNome()

    @Query("SELECT * FROM contato ORDER BY sobrenome ASC")
    fun getContatoOrderPeloSobrenome()

    @Query("SELECT * FROM contato ORDER BY telefone ASC")
    fun getContatoOrderPeloTelefone()


}