package com.example.appcombanco.controller

enum class Tipo {
    nome,
    sobrenome,
    telefone
}