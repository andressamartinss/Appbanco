package com.example.appcombanco.controller

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.appcombanco.model.Contato
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

class ContatoExec (
    private val dao: ContatoDao
): ViewModel(){
    private val _tipo = MutableStateFlow(Tipo.nome)
    private val _contatos = _tipo
        .flatMapLatest { tipo ->
            when(tipo){
                Tipo.nome -> dao.getContatoOrderPeloSobrenome()
                Tipo.sobrenome -> dao.getContatoOrderPeloSobrenome()
                Tipo.telefone -> dao.getContatoOrderPeloTelefone()

            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList())

    private val _estado = MutableStateFlow(Contato())
    val estado = combine(_estado, _tipo, _contatos){ estado, tipo, contato ->
        estado.copy(
            contato = contato,
            tipo = tipo,
        )

    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Contato())

    fun evento(acao: ContatoAcoes){
        when(acao){
            is ContatoAcoes.DeletarContato ->{
                viewModelScope.launch {
                    dao.deleteContato(acao.contato)
                }
            }
            ContatoAcoes.OcultarDialog ->{
                _estado.update {
                    it.copy(
                        adicionarContato = false
                    )
                }
            }

            ContatoAcoes.CadastrarContato ->{
                val nome = estado.value.nome
                val sobrenome =  estado.value.sobrenome
                val telefone = estado.value.telefone

                if(nome.isBlank() || sobrenome.isBlank || telefone.isBlank()){
                    return
                }
                val contato = com.example.appcombanco.controller.Contato(
                    nome = nome,
                    sobrenome =  sobrenome,
                    telefone =  telefone
                )

                viewModelScope.launch {
                    dao.upsertContato(contato)
                }

                _estado.update {
                    it.copy(
                        adicionarContato = false,
                        nome = " ",
                        sobrenome = " ",
                        telefone = " "
                    )
                }
            }
            is ContatoAcoes.SetNome ->{
                _estado.update {
                    it.copy(
                        nome = acao.nome
                    )
                }
            }
            is ContatoAcoes.SetSobrenome ->{
                _estado.update {
                    it.copy(
                        sobrenome = acao.sobrenome
                    )
                }
            }
            is ContatoAcoes.SetTelefone -> {
                _estado.update {
                    it.copy(
                        telefone = acao.telefone
                    )
                }
            }
            is ContatoAcoes.VizualizarDialog ->{
                _estado.update {
                    it.copy(
                        adicionarContato = true
                    )
                }
            }
            is ContatoAcoes.SortearContatos ->{
                _tipo.value = acao.tipo
            }

            else ->{}
        }

    }

}